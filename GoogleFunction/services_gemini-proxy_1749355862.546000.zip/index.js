//Google Function index.js
//@ts-check
// Import necessary modules
// @ts-ignore
const { GoogleGenAI } = require("@google/genai");
// @ts-ignore
const { TextToSpeechClient } = require("@google-cloud/text-to-speech");

// --- Configuration ---
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const GEMINI_MODEL_NAME = process.env.GEMINI_MODEL_NAME || "gemini-1.5-flash";
const GEMINI_PREVIEW_TTS = "gemini-2.5-flash-preview-tts"//The new Text-to-Speech dedicated GENAI API;

// Initialize the Google Generative AI client
const genAI = new GoogleGenAI({ apiKey: GEMINI_API_KEY });

// Initialize the Text-to-Speech client
const textToSpeechClient = new TextToSpeechClient();

// --- Helper Functions (Shared by multiple endpoints) ---

async function getAudioFromSentence(sentence, voiceParams, audioConfig, ssml, generate = false) {
  if (!sentence) {
    console.warn("Attempted to get audio for an empty sentence.");
    return null;
  }

  return await usingTtsAPI();
  
  //return await usingGeminiTtsAPI();

  async function usingTtsAPI() { 
    const input = ssml ? { ssml: sentence } : { text: sentence };
    const request = {
      input: input,
      voice: voiceParams,
      audioConfig: audioConfig,
    };
    try {
      const [response] = await textToSpeechClient.synthesizeSpeech(request);
      const audioContentBase64 = response.audioContent.toString("base64");
      console.log(
        `Text-to-Speech API successful for sentence: "${sentence.substring(
          0,
          50
        )}..."`
      );
      return {
        text: sentence,
        audio: audioContentBase64,
      };
    } catch (ttsError) {
      console.error(
        `Error synthesizing speech for sentence: "${sentence.substring(
          0,
          50
        )}...`,
      );
      throw new Error(`Text-to-Speech failed: ${ttsError.message}`);
    }
  };

  async function usingGeminiTtsAPI() {
    const ask = `Speak in an informative way, as if you were reading from a newspaper or a book. Ensure the text is being read in a native accent and pronounciation. If the text includes words or sentences in another language than the main language in which you answer the query, you must read and pronounce the foreign language words as a native speaker of this foreign language would do. You must read each word of the text in its relevant native language with the relevant accent and pronounciation.`;

    const generate = "Read the text as if you were a teacher dictating the sentence to a student who is taking notes.";

    const config = {
        responseMimeType: "audio/mpeg",
        systemInstruction: generate?generate:ask, //Instruction about how to read the text 
        speechConfig: {
          languageCode: voiceParams.languageCode,
          voiceConfig: {
            prebuiltVoiceConfig: {
              voiceName: voiceParams.name
            }
          },
        },
    };
    
    const generateContentRequest = {
      model: GEMINI_PREVIEW_TTS,
      contents: [{ role: "user", parts: [{ text: sentence }] }],
      config,
    };
  
    try {
      const audioBuffer = await genAI.models.generateContent(generateContentRequest);  
      return {
        text: sentence,
        audio: audioBuffer,
      };
    } catch(error) {
      console.log('Failed to convert the text with the Gemini 2.5 tts API')
      return error
    }
  };
}

async function __callGemini(content, config, model) {
  if (!content || !config) return;
  if (!genAI) throw new Error("genAI is undefined");

  const generateContentRequest = {
    model: model || GEMINI_MODEL_NAME,
    contents: content,
    config: config,
  };

  try {
    return await genAI.models.generateContent(generateContentRequest);
  } catch (geminiError) {
    console.error("Error during Gemini API call:", geminiError.message);
    if (geminiError.response && geminiError.response.error) {
      console.error(
        "Gemini API raw error response:",
        JSON.stringify(geminiError.response.error)
      );
    }
    throw new Error(`Gemini API failed: ${geminiError.message}`);
  }
}

async function callGemini(prompt, jsonResponse = false) {
  console.log("Calling Gemini API with query:", prompt);

  if (!genAI) throw new Error("genAI is undefined");

  //const model = genAI.getGenerativeModel({ model: GEMINI_MODEL_NAME });

  const generateContentRequest = {
    model: GEMINI_MODEL_NAME,
    contents: [{ role: "user", parts: [{ text: prompt }] }],
  };

  if (jsonResponse) {
    generateContentRequest.generationConfig = {
      responseMimeType: "application/json",
    };
  }

  try {
    const result = await genAI.models.generateContent(generateContentRequest);
    console.log(result);
    let text = result.text;

    if (!text) throw new Error("Gemini API failed to return text content.");

    text = text.trim();

    if (!jsonResponse) return text;

    const fenceRegex = /^```(?:json)?\s*\n?(.*?)\n?\s*```$/s;
    const match = text.match(fenceRegex);
    if (match && match[1]) {
      text = match[1].trim();
    }

    const sentences = JSON.parse(text);

    if (
      !Array.isArray(sentences) ||
      !sentences.every((s) => typeof s === "string") ||
      sentences.length === 0
    ) {
      throw new Error(
        `Gemini did not return a valid JSON array of strings. Response: \n ${text}`
      );
    }

    return sentences;
  } catch (geminiError) {
    console.error("Error during Gemini API call:", geminiError.message);
    if (geminiError.response && geminiError.response.error) {
      console.error(
        "Gemini API raw error response:",
        JSON.stringify(geminiError.response.error)
      );
    }
    throw new Error(`Gemini API failed: ${geminiError.message}`);
  }
}

// --- Specific Route Handlers ---

/**
 * Handles requests to /api/sentences to generate multiple sentences and their audio.
 * @param {object} req The HTTP request object.
 * @param {object} res The HTTP response object.
 */

async function __generateSentences(req, res) {
  if (req.method !== "POST") {
    res.status(405).send("Method Not Allowed");
    return;
  }

  console.log("Received request for /api/sentences. Request body:", req.body);
  //!content her is an object that contains 2 genAi prompts: 1 for the text and the other for the audio: content = {text:textContentObject, audio:audioContentObject}.
  // !Similarly config is an object like {text:textConfigObject, audio:audioConfigObject}
  const { content, config, model } = req.body;

  if (!content || !config) {
    return res.status(400).json({
      message:
        "Missing required parameters. Ensure content and config are provided.",
    });
  }

  if (!GEMINI_API_KEY) {
    console.error("Gemini API Key is not configured on the server.");
    return res
      .status(500)
      .json({ error: "Server configuration error: Gemini API Key missing." });
  }

  try {
    const sentences = await getSentences(); //This should return a string[]
    //@ts-ignore
    if (!sentences || !Array.isArray(sentences) || !sentences.length)
      return res.status(500).json({
        error: `Gemini did not return an array of sentences as expected. It returned ${
          JSON.stringify(sentences) || "undefined"
        }`,
      });
    const audios = [];
    //@ts-ignore
    for (const sentence of sentences) {
      audios.push(await getAudioForSentence(sentence));
    }
    return res.status(200).json({ text: sentences, audio: audios });
  } catch (error) {
    res
      .status(500)
      .json({
        error:
          "Something went wrong on the server side while fetching the sentences or the audios",
      });
  }

  async function getSentences() {
    try {
      const sentences = await __callGemini(content.text, config.text, model); //we send the prompt contents and request configuration for the generation of the sentences

      console.log("returned sentences = ", sentences);

      return sentences?.text; //This should be a string[]
    } catch (error) {
      console.log("GenAi failed to return the sentences");
    }
  }

async function getAudioForSentence(sentence) {
    const conent = content.audio;
    const prompt = content[0].parts[0];
    prompt.text = sentence;//We replace 
    const audio = await __callGemini(content.audio, config.audio, model);
    if (!audio) console.log(`Failed to get the audio for; ${sentence}`);
    return audio;
  }
}

async function generateSentences(req, res) {
  if (req.method !== "POST") {
    res.status(405).send("Method Not Allowed");
    return;
  }

  console.log("Received request for /api/sentences. Request body:", req.body);

  const { query, voiceParams, audioConfig } = req.body;

  if (!query || !voiceParams || !audioConfig) {
    return res.status(400).json({
      message:
        "Missing required parameters. Ensure query, sourceLanguage, targetLanguage, voiceParams, audioConfig, sentencesNumber, and wordsNumber are provided.",
    });
  }

  if (!GEMINI_API_KEY) {
    console.error("Gemini API Key is not configured on the server.");
    return res
      .status(500)
      .json({ error: "Server configuration error: Gemini API Key missing." });
  }

  try {
    const sentences = await callGemini(query, true);
    console.log("Gemini API successful. Generated text:", sentences);

    console.log("Calling Text-to-Speech API for text:");
    const audios = [];
    for (let sentence of sentences) {
      audios.push(
        await getAudioFromSentence(
          sentence.trim(),
          voiceParams,
          audioConfig,
          false,
          true
        )
      );
    }
    return res.status(200).json({ sentences: audios });
  } catch (error) {
    console.error("Error in /api/sentences route:", error.message);
    console.error("Error details:", JSON.stringify(error));
    return res.status(500).json({
      error: "Failed to process request for sentences.",
      details:
        process.env.NODE_ENV === "development" ? error.message : undefined,
    });
  }
}

/**
 * Handles requests to /api/ask to get a single answer and its audio.
 * @param {object} req The HTTP request object.
 * @param {object} res The HTTP response object.
 */
async function __askAPI(req, res) {
  if (req.method !== "POST") {
    res.status(405).send("Method Not Allowed");
    return;
  }

  console.log("Received request for /api/ask. Request body:", req.body);

  const { content, config, model } = req.body;

  if (!content || !config) {
    return res.status(400).json({
      message:
        "Missing required parameters. Ensure content and config are provided.",
    });
  }

  if (!GEMINI_API_KEY) {
    console.error("Gemini API Key is not configured on the server.");
    return res
      .status(500)
      .json({ error: "Server configuration error: Gemini API Key missing." });
  }

  try {
    const response = await __callGemini(content.text, config.text, model);
    return res.status(200).json(response);
  } catch (error) {
    console.error("Error in /api/ask route:", error.message);
    console.error("Error details:", JSON.stringify(error));
    return res.status(500).json({
      error: "Failed to process request for ask.",
      // @ts-ignore
      details:
        process.env.NODE_ENV === "development" ? error.message : undefined,
    });
  }
}

async function askAPI(req, res) {
  if (req.method !== "POST") {
    res.status(405).send("Method Not Allowed");
    return;
  }

  console.log("Received request for /api/ask. Request body:", req.body);

  const { query, voiceParams, audioConfig, noAudio } = req.body;

  if (!query || !voiceParams || !audioConfig) {
    return res.status(400).json({
      message:
        "Missing required parameters. Ensure query, voiceParams, and audioConfig are provided.",
    });
  }

  if (!GEMINI_API_KEY) {
    console.error("Gemini API Key is not configured on the server.");
    return res
      .status(500)
      .json({ error: "Server configuration error: Gemini API Key missing." });
  }

  try {
    const responseText = await callGemini(query);
    console.log("Gemini API successful. Generated text:", responseText);

    if (responseText && noAudio)
      return res
        .status(200)
        .json({ response: { text: responseText, audio: null } });

    console.log("Calling Text-to-Speech API for text");
    const audio = await getAudioFromSentence(
      //@ts-expect-error
      responseText?.trim(),
      voiceParams,
      audioConfig,
      true,
      false
    );
    return res.status(200).json({ response: audio });
  } catch (error) {
    console.error("Error in /api/ask route:", error.message);
    console.error("Error details:", JSON.stringify(error));
    return res.status(500).json({
      error: "Failed to process request for ask.",
      // @ts-ignore
      details:
        process.env.NODE_ENV === "development" ? error.message : undefined,
    });
  }
}

// --- Main Cloud Function Entry Point ---
exports.geminiProxy = async (req, res) => {
  // Manually handle CORS headers (essential for your PWA)
  res.set("Access-Control-Allow-Origin", "https://mbibawi.github.io"); // Adjust this to your PWA's domain for security
  res.set("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.set("Access-Control-Allow-Headers", "Content-Type");
  res.set("Access-Control-Max-Age", "3600"); // Cache preflight response for 1 hour

  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    res.status(204).send("");
    return;
  }

  // --- Centralized Routing Logic ---
  if (req.path === "/") {
    if (req.method === "GET") {
      res.status(200).send("Gemini proxy with TTS function is running.");
    } else {
      res.status(405).send("Method Not Allowed");
    }
  } else if (req.path === "/api/sentences") {
    await generateSentences(req, res); // Call the dedicated handler function
  } else if (req.path === "/api/ask") {
    await askAPI(req, res); // Call the dedicated handler function
  } else {
    // Default catch-all for unknown paths
    res.status(404).send("Not Found");
  }
};
